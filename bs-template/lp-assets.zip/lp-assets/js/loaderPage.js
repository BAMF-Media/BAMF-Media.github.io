$(window).load(function () {
    $(".loader").fadeOut("slow");
});
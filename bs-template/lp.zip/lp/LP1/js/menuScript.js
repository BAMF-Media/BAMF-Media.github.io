$(document).ready(function () {

    $("#closeBtnMenu").click(function () {
        $("#navMenu").css({"width": "0"});
    });

    $("#openNav").click(function () {
        $("#navMenu").css({"width": "100%"});
    })
});




